package com.example.lab;

public class DETAD {
}
