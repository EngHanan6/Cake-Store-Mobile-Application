package com.example.lab;





import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity3 extends AppCompatActivity {

    ImageView imgDetail;
    TextView tvName, tvPrice, tvDesc;
    Button btnBuy;
    TextView cakeTextPreview;
    EditText inputMessage;
    Button btnAddText;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        imgDetail = findViewById(R.id.imgDetail);
        tvName = findViewById(R.id.tvDetailName);
        tvPrice = findViewById(R.id.tvDetailPrice);
        tvDesc = findViewById(R.id.tvDetailDesc);
        btnBuy = findViewById(R.id.btnBuyNow);
        btnBuy = findViewById(R.id.btnBuyNow);
        cakeTextPreview = findViewById(R.id.cakeTextPreview);
        inputMessage = findViewById(R.id.inputMessage);
        btnAddText = findViewById(R.id.btnAddText);

        btnAddText.setOnClickListener(v -> {
            String msg = inputMessage.getText().toString().trim();
            cakeTextPreview.setText(msg);
        });



        Intent intent = getIntent();
        String name = intent.getStringExtra("cake_name");
        String price = intent.getStringExtra("cake_price");
        int imgRes = intent.getIntExtra("cake_img", R.drawable.img_2);

        tvName.setText(name);
        tvPrice.setText("SAR " + price);
        imgDetail.setImageResource(imgRes);

        btnBuy.setOnClickListener(v -> {
            Intent i = new Intent(this, MainActivity4.class);
            String summary = name + "\nPrice: SAR " + price;

            // send cake text
            String customText = cakeTextPreview.getText().toString();
            summary += "\nMessage: " + customText;

            i.putExtra("order_summary", summary);
            startActivity(i);
        });

    }}




