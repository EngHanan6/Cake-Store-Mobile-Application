package com.example.lab;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    Button btnCake1, btnCake2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        btnCake1 = findViewById(R.id.btnCake1Details); // note: these ids are btnCake1Details in layout
        btnCake2 = findViewById(R.id.btnCake2Details);


        // Each button opens the detail Activity with explicit intent and passes name, price, drawable id
        btnCake1.setOnClickListener(v -> openDetail("Royal Chocolate", "35", R.drawable.img_3));
        btnCake2.setOnClickListener(v -> openDetail("Vanilla Elegance", "28", R.drawable.img_4));

    }

    private void openDetail(String name, String price, int drawableRes) {
        Intent intent = new Intent(this, MainActivity3.class);
        intent.putExtra("cake_name", name);
        intent.putExtra("cake_price", price);
        intent.putExtra("cake_img", drawableRes);
        startActivity(intent);
    }
}























