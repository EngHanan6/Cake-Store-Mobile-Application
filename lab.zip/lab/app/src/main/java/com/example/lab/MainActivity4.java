package com.example.lab;



import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity4 extends AppCompatActivity {

    TextView tvSummary;
    Button btnConfirm, btnShare;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        tvSummary = findViewById(R.id.tvOrderSummary);
        btnConfirm = findViewById(R.id.btnConfirm);
        btnShare = findViewById(R.id.btnShareOrder);

        String summary = getIntent().getStringExtra("order_summary");
        if (summary != null) tvSummary.setText(summary);

        //  عجرت ةشاشلل  ةيسيئرلا


        btnShare.setOnClickListener(v -> {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/plain");
            share.putExtra(Intent.EXTRA_TEXT, summary);
            startActivity(Intent.createChooser(share, "Share order via"));
        });

    }
    public void FF(View f){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);

    }

}


